package com.test.personaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonaWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonaWebApplication.class, args);
	}

}
