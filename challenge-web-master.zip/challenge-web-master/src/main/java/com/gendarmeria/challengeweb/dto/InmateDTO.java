package com.gendarmeria.challengeweb.dto;

public class InmateDTO {

}
